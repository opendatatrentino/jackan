
## JACKAN RELEASE NOTES

### 0.3.3

20 June 2015

- now creating release zip with jar and dependencies
- added josman and github site plugins to pom
- really pushed to sonatype...


### 0.3.2

6 May 2015

- adapted to josman docs structure

### 0.3.1

 19 January 2015

- implemented reading and searching from CKAN

### 0.2.0

- deprecated version - it's a legacy release for projects depending on it